window.Telegram.WebApp.ready();

document.getElementById("startBtn").addEventListener("click", () => {
  Telegram.WebApp.sendData("start_game");
  Telegram.WebApp.close();
});